// Pega aquí tus credenciales públicas (se pueden exponer en el cliente)
export const SUPABASE_URL = "https://TU-PROYECTO.supabase.co";
export const SUPABASE_ANON_KEY = "TU_ANON_KEY";
